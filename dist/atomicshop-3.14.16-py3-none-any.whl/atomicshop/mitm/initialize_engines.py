import os
from pathlib import Path

from .. import ip_addresses
from ..file_io import tomls
from ..basics.classes import import_first_class_name_from_file_path
from .engines.__reference_general import parser___reference_general, requester___reference_general, \
    responder___reference_general, recorder___reference_general


class ModuleCategory:
    def __init__(self, script_directory: str):
        self.engine_name: str = str()
        self.script_directory: str = script_directory

        self.domain_list: list[str] = list()
        self.domain_exclude_list: list[str] = list()
        self.domain_target_dict: dict = dict()
        self.port_target_dict: dict = dict()

        # 'domains' entries dropped as duplicates (same domain:port after key normalization).
        # import_config reports them, so a stale config line stays visible instead of vanishing.
        self.duplicate_domain_entries: list[dict] = list()

        self.is_localhost: bool = bool()
        self.on_port_connect: dict = dict()
        self.mtls: dict = dict()

        # Optional per-engine SSH override for the get_process_name feature.
        # Both stay None when the engine config has no [process_name] section
        # or when both keys are commented out -- in that case the global
        # config.toml ssh_user / ssh_pass are used at runtime.
        self.ssh_user: str | None = None
        self.ssh_pass: str | None = None

        # Per-engine override of the global get_process_name flag. None = no
        # override (inherit config.toml); True/False = force on/off for this engine.
        self.get_process_name: bool | None = None

        self.parser_file_path: str = str()
        self.requester_file_path: str = str()
        self.responder_file_path: str = str()
        self.recorder_file_path: str = str()

        self.parser_class_object: type[parser___reference_general.ParserGeneral] | None = None
        self.requester_class_object: type[requester___reference_general.RequesterGeneral] | None = None
        self.responder_class_object: type[responder___reference_general.ResponderGeneral] | None = None
        self.recorder_class_object: type[recorder___reference_general.RecorderGeneral] | None = None

    def fill_engine_fields_from_general_reference(self, engines_fullpath: str):
        # Reference module variables.
        self.engine_name = '__reference_general'
        reference_folder_path: str = engines_fullpath + os.sep + self.engine_name
        # Full path to file.
        self.parser_file_path = reference_folder_path + os.sep + "parser___reference_general.py"
        self.requester_file_path = reference_folder_path + os.sep + "requester___reference_general.py"
        self.responder_file_path = reference_folder_path + os.sep + "responder___reference_general.py"
        self.recorder_file_path = reference_folder_path + os.sep + "recorder___reference_general.py"

    def fill_engine_fields_from_config(
            self,
            engine_config_file_path: str,
            print_kwargs: dict = None
    ) -> tuple[int, str]:
        # Read the configuration file of the engine.
        configuration_data = tomls.read_toml_file(engine_config_file_path, **(print_kwargs or {}))

        engine_directory_path: str = str(Path(engine_config_file_path).parent)
        self.engine_name = Path(engine_directory_path).name

        # Getting the parameters from engine config file
        self.domain_list: list[str] = configuration_data['engine']['domains']

        if 'domains_exclude' in configuration_data['engine']:
            self.domain_exclude_list: list[str] = configuration_data['engine']['domains_exclude']

        if 'on_port_connect' in configuration_data:
            self.on_port_connect = configuration_data['on_port_connect']

        if 'mtls' in configuration_data:
            self.mtls = configuration_data['mtls']

        # Optional per-engine SSH override. The whole [process_name] section is
        # optional so older engine_config.toml files (pre-override) keep loading.
        # Both keys must be present together; a partial override (only ssh_user
        # or only ssh_pass) is rejected so we never silently mix an
        # engine-specific user with the global password (or vice versa).
        process_name_section = configuration_data.get('process_name', {})
        engine_ssh_user = process_name_section.get('ssh_user')
        engine_ssh_pass = process_name_section.get('ssh_pass')
        if (engine_ssh_user is None) != (engine_ssh_pass is None):
            raise ValueError(
                f"Engine [{self.engine_name}] config at {engine_config_file_path} "
                f"has a partial [process_name] override: ssh_user and ssh_pass "
                f"must either both be set or both be commented out."
            )
        self.ssh_user = engine_ssh_user
        self.ssh_pass = engine_ssh_pass

        # get_process_name override: absent/commented -> None (inherit global);
        # 0/1 -> force off/on for this engine (resolved in mitm_main.py).
        engine_get_process_name = process_name_section.get('get_process_name')
        self.get_process_name = None if engine_get_process_name is None else bool(engine_get_process_name)

        # If there's module configuration file, but no domains in it, there's no point to continue.
        # Since, each engine is based on domains.
        if not self.domain_list or self.domain_list[0] == '':
            raise ValueError(f"Engine Configuration file doesn't contain any domains: {engine_config_file_path}")

        # This is needed for backwards compatibility before glass 1.8.2, atomicshop 2.20.6
        # When the name of each file was following the pattern: parser_<EngineName>.py, responder_<EngineName>.py, recorder_<EngineName>.py
        if os.path.isfile(f"{engine_directory_path}{os.sep}parser.py"):
            file_name_suffix: str = ''
        else:
            file_name_suffix: str = f"_{self.engine_name}"

        # Full path to file
        self.parser_file_path = f"{engine_directory_path}{os.sep}parser{file_name_suffix}.py"
        self.requester_file_path = f"{engine_directory_path}{os.sep}requester{file_name_suffix}.py"
        self.responder_file_path = f"{engine_directory_path}{os.sep}responder{file_name_suffix}.py"
        self.recorder_file_path = f"{engine_directory_path}{os.sep}recorder{file_name_suffix}.py"

        for domain_index, domain_port_string in enumerate(self.domain_list):
            # Splitting the domain and port
            if ':' in domain_port_string:
                domain, port = domain_port_string.split(':')
            else:
                error_string: str = f"No [domain:port] pair found in: {domain_port_string}"
                return 1, error_string

            # DNS names are case-insensitive (RFC 4343); normalize keys for case-safe matching.
            domain = domain.strip().lower().rstrip(".")

            port = int(port)
            if domain not in self.domain_target_dict:
                self.domain_target_dict[domain] = {'ip': None, 'ports': [port]}
            # Key normalization merges case/trailing-dot variants, so the same domain:port can
            # arrive twice. A repeat would bind the domain's single IP twice and the listener's
            # port-in-use pre-check would hit its own socket. Unique ports, config order kept.
            elif port not in self.domain_target_dict[domain]['ports']:
                self.domain_target_dict[domain]['ports'].append(port)
            else:
                self.duplicate_domain_entries.append({
                    'entry': domain_port_string,
                    'position': domain_index + 1,
                    'domain': domain,
                    'port': port
                })

        for port, value in self.on_port_connect.items():
            self.port_target_dict[port] = {'ip': None, 'port': int(port)}

            # If it is not an IP address (e.g. <IP:PORT>) it will be treated as file path.
            if ':' not in value:
                self.on_port_connect[port] = f'{engine_directory_path}{os.sep}{value}'

        for subdomain, file_name in self.mtls.items():
            self.mtls[subdomain] = f'{engine_directory_path}{os.sep}{file_name}'

        return 0, ''

    def initialize_engine(
            self,
            reference_general: bool = False,
            print_kwargs: dict = None
    ) -> tuple[int, str]:
        try:
            if not reference_general:
                self.parser_class_object = import_first_class_name_from_file_path(
                    self.script_directory, self.parser_file_path, **(print_kwargs or {}))
                self.requester_class_object = import_first_class_name_from_file_path(
                    self.script_directory, self.requester_file_path, **(print_kwargs or {}))
                self.responder_class_object = import_first_class_name_from_file_path(
                    self.script_directory, self.responder_file_path, **(print_kwargs or {}))
                self.recorder_class_object = import_first_class_name_from_file_path(
                    self.script_directory, self.recorder_file_path, **(print_kwargs or {}))
            else:
                self.parser_class_object = parser___reference_general.ParserGeneral
                self.requester_class_object = requester___reference_general.RequesterGeneral
                self.responder_class_object = responder___reference_general.ResponderGeneral
                self.recorder_class_object = recorder___reference_general.RecorderGeneral
        except ModuleNotFoundError as e:
            return 1, str(e)

        return 0, ''


def format_duplicate_domain_entries(engines_list: list) -> str:
    """One line per ignored duplicate 'domains' entry across all engines; '' when there are none.

    Domain keys are normalized (lowercased, trailing dot stripped), so entries that look
    distinct in the TOML can collapse onto the same domain:port. The report quotes the
    entry verbatim and gives its position in the list, so it can be found and deleted.

    Emitted by mitm_main.startup_output(), not from the config parse path: every TCP
    server process re-parses the engine configs, so reporting there repeats it per process.
    """

    lines: list[str] = list()
    for engine in engines_list:
        for duplicate in engine.duplicate_domain_entries:
            lines.append(
                f"  Engine [{engine.engine_name}] domains entry #{duplicate['position']}: "
                f"'{duplicate['entry']}' -> {duplicate['domain']}:{duplicate['port']} is already listed.")

    if not lines:
        return ''

    return ("[!] Duplicate [domain:port] entries in engine configs were ignored "
            "(one listening socket per domain:port):\n" + "\n".join(lines))


def get_ipv4_from_engine_on_connect_port(
        address_or_file_path: str
) -> tuple[str, str] | None:
    """
    Function to get the IPv4 address from the engine on connect port.

    :param address_or_file_path: string, "ip_address:port" or file path that was set in the engine on_port_connect.
    :return: string, IPv4 address that was parsed from the 'ip_port_address'.

    """

    def get_ip_port_from_address(ip_port_address: str) -> tuple[str, str] | None:
        """
        Function to get the IP address and port from the address string.
        If the address is a file path, it will return an empty string.
        """
        if ':' in ip_port_address:
            ipv4_to_connect, port_to_connect = ip_port_address.split(':')
            if ip_addresses.is_ip_address(ipv4_to_connect, ip_type='ipv4'):
                return ipv4_to_connect, port_to_connect
            else:
                return None
        else:
            return None

    # Try to get it as IP address.
    ip_port_address_from_config = get_ip_port_from_address(address_or_file_path)

    # If it is not an IP address, try to read it as a text file.
    if not ip_port_address_from_config:
        if os.path.isfile(address_or_file_path):
            with open(address_or_file_path, 'r', encoding='utf-8') as file:
                first_line = file.readline().strip()

            ip_port_address_from_config = get_ip_port_from_address(first_line)
        else:
            return None

    return ip_port_address_from_config


def assign_class_by_domain(
        engines_list: list,
        message_domain_name: str,
        reference_module
):
    """
    Assigning external class object by message domain received from client. If the domain is not in the list,
    the reference general module will be assigned.
    """

    # In case SNI came empty in the request from client, then there's no point in iterating through engine domains.
    module = None
    if message_domain_name:
        # DNS names are case-insensitive (RFC 4343); normalize before matching engine domains.
        message_domain_name = message_domain_name.strip().lower().rstrip(".")
        # If engine/s exit, the engines_list will not be empty, then we'll iterate through the list of engines
        # to find the domain in the list of domains of the engine.
        if engines_list:
            # Checking if current domain is in engines' domain list to activate domain specific engine
            for function_module in engines_list:
                # The list: matches_list = ["domain1.com", "domain2.com", "domain3.com"]
                # The string: a_string = "www.domain1.com"
                # Checking that the message subdomain + domain contains current module's domain name
                # Template Should be like this: if any(x in a_string for x in matches_list):

                # On the other hand if you want to find if partial string is
                # in the list of strings: if any(a_string in x for x in matches_list):
                # In this case list is the same and string: a_string = domain
                if any(x in message_domain_name for x in function_module.domain_target_dict.keys()):
                    # Assigning module by current engine of the domain
                    module = function_module

                    # If the domain was found in the current list of class domains, we can stop the loop
                    break

                # If the module wasn't found by the domain, check it by the port.
                if not module:
                    # Get the list of all the ip addresses in the on_port_connect dict.
                    list_of_ip_addresses_per_port: list[str] = []
                    for port, value in function_module.on_port_connect.items():
                        ipv4_to_connect, _ = get_ipv4_from_engine_on_connect_port(value)
                        list_of_ip_addresses_per_port.append(ipv4_to_connect)

                    # Checking if the message domain name is in the list of ip addresses per port.
                    if any(x in message_domain_name for x in list_of_ip_addresses_per_port):
                        # Assigning module by current engine of the port
                        module = function_module

                        # If the port was found in the current list of class ports, we can stop the loop
                        break

    # If none of the domains were found in the engine domains list, then we'll assign reference module.
    # It's enough to check only parser, since responder and recorder also will be empty.
    # This section is also relevant if SNI came empty in the request from the client and no domain was passed by the
    # DNS Server.
    if not module:
        module = reference_module

    return module
