from atomicshop.wrappers import wslw


def main():
    wslw.install_wsl()


if __name__ == '__main__':
    main()
