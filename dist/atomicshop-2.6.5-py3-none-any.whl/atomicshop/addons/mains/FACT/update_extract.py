from atomicshop.wrappers.factw.fact_extractor import get_extractor


def main():
    get_extractor.get_extractor_script()


if __name__ == '__main__':
    main()
