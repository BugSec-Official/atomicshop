import multiprocessing
import multiprocessing.queues  # multiprocessing.Queue is a factory method; the real class lives here
import threading
import select
from typing import Literal, Union, Callable, Any
from pathlib import Path
import socket
import shutil
import os

import paramiko

from ...mitm import initialize_engines
from ..psutilw import psutil_networks
from ..certauthw import certauthw
from ..loggingw import loggingw
from ...permissions import permissions
from ... import filesystem, certificates
from ...basics import booleans, threads, tracebacks
from ...print_api import print_api
from ...import ssh_remote

from . import (
    creator, accepter, statistics_csv, ssl_base,
    sni, buffered_socket, socket_client,
)


class SocketWrapperPortInUseError(Exception):
    pass


class SocketWrapperConfigurationValuesError(Exception):
    pass


# from ... import queues
# SNI_QUEUE = queues.NonBlockQueue()
LOGS_DIRECTORY_NAME: str = 'logs'


class SocketWrapper:
    def __init__(
            self,
            ip_address: str,
            port: int,
            engine: initialize_engines.ModuleCategory | None = None,
            forwarding_dns_service_ipv4_list___only_for_localhost: list | None = None,
            ca_certificate_name: str | None = None,
            ca_certificate_filepath: str | None = None,
            ca_certificate_crt_filepath: str | None = None,
            install_ca_certificate_to_root_store: bool = False,
            uninstall_unused_ca_certificates_with_ca_certificate_name: bool = False,
            default_server_certificate_usage: bool = False,
            default_server_certificate_name: str | None = None,
            default_certificate_domain_list: list | None = None,
            default_server_certificate_directory: str | None = None,
            sni_custom_callback_function: Callable[..., Any] | None = None,
            sni_use_default_callback_function: bool = False,
            sni_use_default_callback_function_extended: bool = False,
            sni_add_new_domains_to_default_server_certificate: bool = False,
            sni_create_server_certificate_for_each_domain: bool = False,
            sni_server_certificates_cache_directory: str | None = None,
            reuse_server_socket_certificate: bool = False,
            reuse_server_socket_certificate_download_directory: str | None = None,
            is_offline: bool = False,
            fail_fast_on_origin_connect_error: bool = False,
            skip_extension_id_list: list | None = None,
            custom_server_certificate_usage: bool = False,
            custom_server_certificate_path: str | None = None,
            custom_private_key_path: str | None = None,
            get_process_name: bool = False,
            ssh_user: str | None = None,
            ssh_pass: str | None = None,
            ssh_script_to_execute: Union[
                Literal['process_from_port'],
                None
            ] = None,
            logs_directory: str | None = None,
            logger_name: str = 'SocketWrapper',
            logger_queue: multiprocessing.queues.Queue | None = None,
            statistics_logger_name: str = 'statistics',
            statistics_logger_queue: multiprocessing.queues.Queue | None = None,
            exceptions_logger_name: str = 'SocketWrapperExceptions',
            exceptions_logger_queue: multiprocessing.queues.Queue | None = None,
            enable_sslkeylogfile_env_to_client_ssl_context: bool = False,
            sslkeylog_file_path: str | None = None,
            print_kwargs: dict | None = None,
    ):
        """
        Socket Wrapper class that will be used to create sockets, listen on them, accept connections and send them to
        new threads.

        :param ca_certificate_name: CA certificate name.
        :param ca_certificate_filepath: CA certificate file path with '.pem' extension.
        :param ca_certificate_crt_filepath: CA certificate file path with '.crt' extension.
            This file will be created from the PEM file 'ca_certificate_filepath' for manual installation.
        :param install_ca_certificate_to_root_store: boolean, if True, CA certificate will be installed
            to the root store.
        :param uninstall_unused_ca_certificates_with_ca_certificate_name: boolean, if True, unused CA certificates
            with provided 'ca_certificate_name' will be uninstalled.
        :param default_server_certificate_usage: boolean, if True, default server certificate will be used
            for each incoming socket.
        :param sni_custom_callback_function: callable, custom callback function that will be executed when
            there is a SNI present in the request.

            Example: custom callback function to set the 'server_hostname' for the socket with the domain name from SNI:
                    def sni_handle(
                            sni_ssl_socket: ssl.SSLSocket,
                            sni_destination_name: str,
                            sni_ssl_context: ssl.SSLContext):
                        # Set 'server_hostname' for the socket.
                        sni_ssl_socket.server_hostname = sni_destination_name

                        return sni_handle

            The function should accept 3 arguments:
                sni_ssl_socket: ssl.SSLSocket, SSL socket object.
                sni_destination_name: string, domain name from SNI.
                sni_ssl_context: ssl.SSLContext, SSL context object.

            These parameters are default for any SNI handler function, so you can use them in your custom function.

        :param sni_use_default_callback_function: boolean, if True, default callback function will be used.
            The function will set the 'server_hostname' for the socket with the domain name from SNI.
            The example in 'sni_custom_callback_function' parameter is the function that will be used.
        :param sni_use_default_callback_function_extended: boolean, if True, default callback function will be used
            with extended functionality. This feature will handle all the features and parameters that are set in
            the SocketWrapper object that are related to SNI. THis includes certificate management for each domain,
            adding new domains to the default certificate, creating new certificates for each domain, etc.
            This feature also utilizes the 'request_domain_queue' parameter to get the domain name that was requested
            from the DNS server (atomicshop.wrappers.socketw.dns_server).
        :param sni_add_new_domains_to_default_server_certificate: boolean, if True, new domains that hit the tcp
            server will be added to default server certificate.
        :param sni_create_server_certificate_for_each_domain: boolean, if True, server certificate will be
            created and used for each domain that hit the tcp server.
        :param reuse_server_socket_certificate: boolean, if True, server certificate will be
            downloaded from the server socket.
        :param reuse_server_socket_certificate_download_directory: string, path to directory where
            server certificate will be downloaded from the server socket.
        :param is_offline: bool, when True the server runs without an upstream/origin connection
            (offline responder mode).
        :param fail_fast_on_origin_connect_error: bool, when True abort before the client TLS
            handshake if the origin is unreachable; when False (default) complete the handshake
            and record the connect error.
        :param default_server_certificate_name: default server certificate name.
        :param default_certificate_domain_list: list of string, domains to create the default certificate with.
        :param default_server_certificate_directory: string, path to directory where default certificate file
            will be stored.
        :param sni_server_certificates_cache_directory: string, path to directory where all server certificates for
            each domain will be created.
        :param skip_extension_id_list: list of string, list of extension IDs that will be skipped when processing
            the certificate from the server socket.
            Example: ['1.3.6.1.5.5.7.3.2', '2.5.29.31', '1.3.6.1.5.5.7.1.1']
        :param custom_server_certificate_usage: boolean, if True, custom server certificate will be used.
        :param custom_server_certificate_path: string, path to custom server certificate.
        :param custom_private_key_path: string, path to custom private key.
            server certificates from the server socket.
        :param get_process_name: boolean, if the process name and command line should be gathered from the socket.
            If the socket came from remote host we will try ti get the process name from the remote host by SSH.
            By default, we don't get the process name, because we're using psutil to get the process name and command
            line, but if the process is protected by the system, then command line will be empty.
            It's up to user to decide if to run the script with root privileges or not, this is only relevant if
            the script is running on the same host.
        :param ssh_user: string, SSH username that will be used to connect to remote host.
        :param ssh_pass: string, SSH password that will be used to connect to remote host.
        :param ssh_script_to_execute: string, script that will be executed to get the process name on ssh remote host.
        :param logs_directory: string, path to directory where daily statistics.csv files and all the other logger
            files will be stored. After you initialize the SocketWrapper object, you can get the statistics_writer
            object from it and use it to write statistics to the file in a worker thread.

            socket_wrapper_instance = SocketWrapper(...)
            statistics_writer = socket_wrapper_instance.statistics_writer

            statistics_writer: statistics_csv.StatisticsCSVWriter object, there is a logger object that
                will be used to write the statistics file.
        :param logger_name: string, name of the logger that will be used to log messages.
        :param logger_queue: multiprocessing.Queue, queue that will be used to log messages in multiprocessing.
            You need to start the logger listener in the main process to handle the queue.
        :param statistics_logger_name: string, name of the logger that will be used to log statistics.
        :param statistics_logger_queue: multiprocessing.Queue, queue that will be used to log statistics in
            multiprocessing. You need to start the logger listener in the main process to handle the queue.
        :param exceptions_logger_name: string, name of the logger that will be used to log exceptions.
        :param exceptions_logger_queue: multiprocessing.Queue, queue that will be used to log exceptions in
            multiprocessing. You need to start the logger listener in the main process to handle the queue.
        :param enable_sslkeylogfile_env_to_client_ssl_context: boolean, if True, each client SSL context
            that will be created by the SocketWrapper will have save the SSL handshake keys to the file
            defined in 'sslkeylog_file_path' parameter.
        :param sslkeylog_file_path: string, path to file where SSL handshake keys will be saved.
            If not provided and 'enable_sslkeylogfile_env_to_client_ssl_context' is True, then
            the environment variable 'SSLKEYLOGFILE' will be used.
        :param print_kwargs: dict, additional arguments to pass to the print function.
        """

        self.ip_address: str = ip_address
        self.port: int = port
        self.engine: initialize_engines.ModuleCategory | None = engine
        self.ca_certificate_name: str | None = ca_certificate_name
        self.ca_certificate_filepath: str | None = ca_certificate_filepath
        self.ca_certificate_crt_filepath: str | None = ca_certificate_crt_filepath
        self.install_ca_certificate_to_root_store: bool = install_ca_certificate_to_root_store
        self.uninstall_unused_ca_certificates_with_ca_certificate_name: bool = \
            uninstall_unused_ca_certificates_with_ca_certificate_name
        self.default_server_certificate_usage: bool = default_server_certificate_usage
        self.default_server_certificate_name: str | None = default_server_certificate_name
        self.default_certificate_domain_list: list | None = default_certificate_domain_list
        self.default_server_certificate_directory: str | None = default_server_certificate_directory
        self.sni_custom_callback_function: Callable[..., Any] | None = sni_custom_callback_function
        self.sni_use_default_callback_function: bool = sni_use_default_callback_function
        self.sni_use_default_callback_function_extended: bool = sni_use_default_callback_function_extended
        self.sni_add_new_domains_to_default_server_certificate: bool = sni_add_new_domains_to_default_server_certificate
        self.sni_create_server_certificate_for_each_domain: bool = sni_create_server_certificate_for_each_domain
        self.sni_server_certificates_cache_directory: str | None = sni_server_certificates_cache_directory
        self.reuse_server_socket_certificate: bool = reuse_server_socket_certificate
        self.reuse_server_socket_certificate_download_directory: str | None = \
            reuse_server_socket_certificate_download_directory
        self.is_offline: bool = is_offline
        self.fail_fast_on_origin_connect_error: bool = fail_fast_on_origin_connect_error
        self.skip_extension_id_list: list | None = skip_extension_id_list
        self.custom_server_certificate_usage: bool = custom_server_certificate_usage
        self.custom_server_certificate_path: str | None = custom_server_certificate_path
        self.custom_private_key_path: str | None = custom_private_key_path
        self.get_process_name: bool = get_process_name
        self.ssh_user: str | None = ssh_user
        self.ssh_pass: str | None = ssh_pass
        self.ssh_script_to_execute = ssh_script_to_execute
        self.forwarding_dns_service_ipv4_list___only_for_localhost = (
            forwarding_dns_service_ipv4_list___only_for_localhost)
        self.enable_sslkeylogfile_env_to_client_ssl_context: bool = (
            enable_sslkeylogfile_env_to_client_ssl_context)
        self.sslkeylog_file_path: str | None = sslkeylog_file_path
        self.print_kwargs: dict | None = print_kwargs

        self.socket_object = None

        # Server certificate file path that will be loaded into SSL Context.
        self.server_certificate_file_path: str = str()
        self.server_private_key_file_path = None

        self.sni_received_dict: dict = dict()
        self.sni_execute_extended: bool = False
        self.certauth_wrapper = None

        # Defining list of threads, so we can "join()" them in the end all at once.
        self.threads_list: list = list()

        # Defining listening sockets list, which will be used with "select" library in 'loop_for_incoming_sockets'.
        self.listening_sockets: list = list()

        if self.get_process_name:
            if self.ssh_user is None:
                raise SocketWrapperConfigurationValuesError("ssh_user is required when get_process_name is True")
            if self.ssh_pass is None:
                raise SocketWrapperConfigurationValuesError("ssh_pass is required when get_process_name is True")

        # Per-process SSH lookup handle (talks to the central broker). Assigned by the
        # TCP server process after construction; None when get_process_name is off.
        self.ssh_lookup_client = None

        # If logs directory was not set, we will use the working directory.
        if not logs_directory:
            logs_directory = str(Path.cwd() / LOGS_DIRECTORY_NAME)
        self.logs_directory: str = logs_directory

        if not logger_name:
            logger_name = 'SocketWrapper'
        self.logger_name: str = logger_name
        self.logger_name_listener: str = f"{logger_name}.listener"

        if loggingw.is_logger_exists(self.logger_name_listener):
            self.logger = loggingw.get_logger_with_level(self.logger_name_listener)
        elif not logger_queue:
            _ = loggingw.create_logger(
                logger_name=logger_name,
                directory_path=self.logs_directory,
                add_stream=True,
                add_timedfile_with_internal_queue=True,
                formatter_streamhandler='DEFAULT',
                formatter_filehandler='DEFAULT'
            )

            self.logger = loggingw.get_logger_with_level(self.logger_name_listener)
        else:
            _ = loggingw.create_logger(
                logger_name=logger_name,
                add_queue_handler=True,
                log_queue=logger_queue
            )
            self.logger = loggingw.get_logger_with_level(self.logger_name_listener)

        self.statistics_writer = statistics_csv.StatisticsCSVWriter(
            logger_name=statistics_logger_name,
            directory_path=self.logs_directory,
            log_queue=statistics_logger_queue,
            add_queue_handler_no_listener_multiprocessing=True
        )

        if not exceptions_logger_name:
            exceptions_logger_name = 'SocketWrapperExceptions'

        self.exceptions_logger = loggingw.ExceptionCsvLogger(
            logger_name=exceptions_logger_name,
            directory_path=self.logs_directory,
            log_queue=exceptions_logger_queue,
            add_queue_handler_no_listener_multiprocessing=True
        )

        self.test_config()

    def test_config(self):
        if self.ca_certificate_name is None:
            raise RuntimeError("ca_certificate_name is required")
        if self.ca_certificate_filepath is None:
            raise RuntimeError("ca_certificate_filepath is required")
        if self.ca_certificate_crt_filepath is None:
            raise RuntimeError("ca_certificate_crt_filepath is required")
        if self.sni_server_certificates_cache_directory is None:
            raise RuntimeError("sni_server_certificates_cache_directory is required")

        if self.sni_custom_callback_function and (
                self.sni_use_default_callback_function or self.sni_use_default_callback_function_extended):
            message = "You can't use both custom and default SNI function at the same time."
            raise SocketWrapperConfigurationValuesError(message)

        if self.sni_use_default_callback_function_extended and not self.sni_use_default_callback_function:
            message = "You can't use extended SNI function without default SNI function."
            raise SocketWrapperConfigurationValuesError(message)

        if self.sni_use_default_callback_function and self.sni_custom_callback_function:
            message = \
                "You can't set both [sni_use_default_callback_function = True] and [sni_custom_callback_function]."
            raise SocketWrapperConfigurationValuesError(message)

        try:
            booleans.is_only_1_true_in_list(
                booleans_list_of_tuples=[
                    (self.default_server_certificate_usage, 'default_server_certificate_usage'),
                    (self.sni_create_server_certificate_for_each_domain,
                     'sni_create_server_certificate_for_each_domain'),
                    (self.custom_server_certificate_usage, 'custom_server_certificate_usage')
                ],
                raise_if_all_false=True
            )
        except ValueError as e:
            raise SocketWrapperConfigurationValuesError(str(e))

        if not self.default_server_certificate_usage and \
                self.sni_add_new_domains_to_default_server_certificate:
            message = "No point setting [sni_add_new_domains_to_default_server_certificate = True]\n" \
                      "If you're not going to use default certificates [default_server_certificate_usage = False]"
            raise SocketWrapperConfigurationValuesError(message)

        if self.reuse_server_socket_certificate and \
                not self.sni_create_server_certificate_for_each_domain:
            message = "You set [reuse_server_socket_certificate = True],\n" \
                      "But you didn't set [sni_create_server_certificate_for_each_domain = True]."
            raise SocketWrapperConfigurationValuesError(message)

        if self.custom_server_certificate_usage and \
                not self.custom_server_certificate_path:
            message = "You set [custom_server_certificate_usage = True],\n" \
                      "But you didn't set [custom_server_certificate_path]."
            raise SocketWrapperConfigurationValuesError(message)

        # If 'custom_certificate_usage' was set to 'True'.
        if self.custom_server_certificate_usage:
            if self.custom_server_certificate_path is None:
                raise RuntimeError("custom_server_certificate_path is required when custom_server_certificate_usage is True")
            # Check file existence.
            if not filesystem.is_file_exists(file_path=self.custom_server_certificate_path):
                message = f"File not found: {self.custom_server_certificate_path}"
                print_api(message, color='red', logger=self.logger)
                return 1

            # And if 'custom_private_key_path' field was populated in [advanced] section, we'll check its existence.
            if self.custom_private_key_path:
                # Check private key file existence.
                if not filesystem.is_file_exists(file_path=self.custom_private_key_path):
                    message = f"File not found: {self.custom_private_key_path}"
                    print_api(message, color='red', logger=self.logger)
                    return 1

        # Check if the port is in usable port range.
        if not (0 < self.port < 65536):
            message = f"Port number [{self.port}] is out of usable port range (1-65535)."
            raise SocketWrapperConfigurationValuesError(message)

        # Checking if listening address is in use.
        listening_check_list = [f"{self.ip_address}:{self.port}"]
        port_in_use = psutil_networks.get_processes_using_port_list(listening_check_list)
        if port_in_use:
            error_messages: list = list()
            for port, process_info in port_in_use.items():
                error_messages.append(f"Port [{port}] is already in use by process: {process_info}")
            raise SocketWrapperPortInUseError("\n".join(error_messages))

        # Creating CA certificate if it doesn't exist.
        if not filesystem.is_file_exists(file_path=self.ca_certificate_filepath):
            # Initialize CertAuthWrapper.
            ca_certificate_directory: str = str(Path(self.ca_certificate_filepath).parent)
            certauth_wrapper = certauthw.CertAuthWrapper(
                ca_certificate_name=self.ca_certificate_name,
                ca_certificate_filepath=self.ca_certificate_filepath,
                server_certificate_directory=ca_certificate_directory
            )

            # Create CA certificate if it doesn't exist.
            certauth_wrapper.create_use_ca_certificate()

            certificates.write_crt_certificate_file_in_pem_format_from_pem_file(
                pem_file_path=self.ca_certificate_filepath,
                crt_file_path=self.ca_certificate_crt_filepath)

            # If someone removed the CA certificate file manually, and now it was created, we also need to
            # clear the cached certificates.
            try:
                shutil.rmtree(self.sni_server_certificates_cache_directory)
            # If the directory doesn't exist it will throw an exception, which is OK.
            except FileNotFoundError:
                pass

            os.makedirs(self.sni_server_certificates_cache_directory, exist_ok=True)
            print_api("Removed cached server certificates.", logger=self.logger)
        else:
            os.makedirs(self.sni_server_certificates_cache_directory, exist_ok=True)

        if self.install_ca_certificate_to_root_store:
            if not self.ca_certificate_filepath:
                message = "You set [install_ca_certificate_to_root_store = True],\n" \
                          "But you didn't set [ca_certificate_filepath]."
                raise SocketWrapperConfigurationValuesError(message)

            # Before installation check if there are any unused certificates with the same name.
            if self.uninstall_unused_ca_certificates_with_ca_certificate_name:
                # Check how many certificates with our ca certificate name are installed.
                is_installed_by_name, certificate_list_by_name = certificates.is_certificate_in_store(
                    issuer_name=self.ca_certificate_name)
                # If there is more than one certificate with the same name, delete them all.
                if is_installed_by_name and len(certificate_list_by_name) > 1:
                    message = f"More than one certificate with the same issuer name is installed. Removing all..."
                    print_api(message, color='yellow', logger=self.logger)
                    certificates.delete_certificate_by_issuer_name(self.ca_certificate_name)
                # If there is only one certificate with the same name, check if it is the same certificate.
                elif is_installed_by_name and len(certificate_list_by_name) == 1:
                    is_installed_by_file, certificate_list_by_file = certificates.is_certificate_in_store(
                        certificate=self.ca_certificate_filepath, by_cert_thumbprint=True, by_cert_issuer=True,
                        print_kwargs=self.print_kwargs)
                    # If the certificate is not the same, delete it.
                    if not is_installed_by_file:
                        if not permissions.is_admin():
                            raise SocketWrapperConfigurationValuesError(
                                "You need to run the script with admin rights to uninstall the unused certificates.")
                        message = (
                            f"Certificate with the same issuer name is installed, but it is not the same certificate. "
                            f"Removing...")
                        print_api(message, color='yellow', logger=self.logger)
                        certificates.delete_certificate_by_issuer_name(
                            self.ca_certificate_name, store_location="ROOT", print_kwargs={'logger': self.logger})

            if self.install_ca_certificate_to_root_store:
                # Install CA certificate to the root store if it is not installed.
                is_installed_by_file, certificate_list_by_file = certificates.is_certificate_in_store(
                    certificate=self.ca_certificate_filepath, by_cert_thumbprint=True, by_cert_issuer=True,
                    print_kwargs=self.print_kwargs
                )
                if not is_installed_by_file:
                    if not permissions.is_admin():
                        raise SocketWrapperConfigurationValuesError(
                            "You need to run the script with admin rights to install the CA certificate.")
                    certificates.install_certificate_file(
                        self.ca_certificate_filepath, store_location="ROOT",
                        print_kwargs={'logger': self.logger, 'color': 'blue'})

    # Creating listening sockets.
    def create_socket_ipv4_tcp(self, ip_address: str, port: int):
        self.sni_execute_extended = True
        self.socket_object = creator.create_socket_ipv4_tcp()
        creator.add_reusable_address_option(self.socket_object)
        creator.bind_socket_with_ip_port(self.socket_object, ip_address, port, logger=self.logger)
        creator.set_listen_on_socket(self.socket_object, logger=self.logger)

        return self.socket_object

    def start_listening_socket(
            self,
            callable_function: Callable[..., Any],
            callable_args: tuple = ()
    ):
        """
        Start listening on a single socket with given IP address and port.
        This function is used to start listening on a single socket, for example, when you want to listen on a specific
        IP address and port.

        :param callable_function: callable, function that you want to execute when client
            socket received by 'accept()' and connection has been made.
        :param callable_args: tuple, that will be passed to 'callable_function' when it will be called.
        :return: None
        """

        if self.engine:
            acceptor_name: str = f"acceptor-{self.engine.engine_name}-{self.ip_address}:{self.port}"
        else:
            acceptor_name: str = f"acceptor-{self.ip_address}:{self.port}"

        socket_by_port = self.create_socket_ipv4_tcp(self.ip_address, self.port)
        threading.Thread(
            target=self.listening_socket_loop,
            args=(socket_by_port, callable_function, callable_args),
            name=acceptor_name,
            daemon=True
        ).start()

    def listening_socket_loop(
            self,
            listening_socket_object: socket.socket,
            callable_function: Callable[..., Any],
            callable_args=()
    ):
        """
        Loop to wait for new connections, accept them and send to new threads.
        The boolean variable was declared True in the beginning of the script and will be set to False if the process
        will be killed or closed.

        :param listening_socket_object: listening socket that was created with bind.
        :param callable_function: callable, function that you want to execute when client
            socket received by 'accept()' and connection has been made.
        :param callable_args: tuple, that will be passed to 'function_reference' when it will be called.
            Your function should be able to accept these arguments before the 'callable_args' tuple:
            (client_socket, process_name, is_tls, domain_from_dns_server).
            Meaning that 'callable_args' will be added to the end of the arguments tuple like so:
            (client_socket, process_name, is_tls, tls_type, tls_version, domain_from_dns_server,
            *callable_args).

            client_socket: socket, client socket that was accepted.
            process_name: string, process name that was gathered from the socket.
            is_tls: boolean, if the socket is SSL/TLS.
            domain_from_dns_server: string, domain that was requested from DNS server.
        :return:
        """

        if self.engine is None:
            raise RuntimeError("engine is required for listening_socket_loop")

        listening_sockets: list[socket.socket] = [listening_socket_object]

        while True:
            engine_name: str = ''
            source_ip: str = ''
            dest_port: int = 0
            destination_domain: str = ''

            try:
                # Using "select.select" which is currently the only API function that works on all
                # operating system types: Windows / Linux / BSD.
                # To accept connection, we don't need "writable" and "exceptional", since "readable" holds the currently
                # connected socket.
                readable, writable, exceptional = select.select(listening_sockets, [], [])
                listening_socket_object: socket.socket = readable[0]

                listening_ip, listening_port = listening_socket_object.getsockname()
                destination_domain = self._resolve_domain_for_listening_socket(listening_ip, listening_port)
                engine_name = get_engine_name(destination_domain, [self.engine])

                # Wait from any connection on "accept()".
                # 'client_socket' is socket or ssl socket, 'client_address' is a tuple (ip_address, port).
                client_socket, client_address, accept_error_message = accepter.accept_connection(
                    listening_socket_object, domain_from_dns_server=destination_domain,
                    print_kwargs={'logger': self.logger})

                source_ip: str = client_address[0]
                source_port: int = client_address[1]
                dest_port: int = listening_port

                message: str = f"Accepted connection from [{source_ip}:{source_port}] to [{listening_ip}:{dest_port}] | domain: {destination_domain}"
                print_api(message, logger=self.logger)

                # If 'accept()' function worked well, then 'client_socket' won't be empty.
                if client_socket:
                    # Spawn thread immediately for connection handling — TLS detection,
                    # SSL wrapping, and callable_function all run in the per-connection thread
                    # so the accept loop is never blocked by slow clients.
                    thread_current = threading.Thread(
                        target=self._serve_connection,
                        args=(client_socket, client_address, engine_name, destination_domain,
                              dest_port, callable_function, callable_args),
                        daemon=True
                    )
                    thread_current.start()
                    self.threads_list.append(thread_current)

                    self.logger.info(
                        f"Accepted connection, thread created [{source_ip}:{source_port}]. "
                        f"Continue listening...")
                # Else, if no client_socket was opened during accept, then print the error.
                else:
                    self.statistics_writer.write_accept_error(
                        engine=engine_name,
                        source_ip=source_ip,
                        error_message=accept_error_message,
                        dest_port=str(dest_port),
                        host=destination_domain,
                        process_name='')
            except (
                ConnectionResetError, EOFError, TimeoutError,
                paramiko.ssh_exception.SSHException, paramiko.ssh_exception.NoValidConnectionsError,
                ssh_remote.SSHRemoteWrapperNoPythonFound
            ) as e:
                exception_string: str = tracebacks.get_as_string()
                full_string: str = f"{str(e)} | {exception_string}"
                self.statistics_writer.write_accept_error(
                    engine=engine_name,
                    source_ip=source_ip,
                    error_message=full_string,
                    dest_port=str(dest_port),
                    host=destination_domain,
                    process_name='')
            except Exception as e:
                _ = e
                exception_string: str = tracebacks.get_as_string()
                full_string: str = f"Engine: [{engine_name}] | {exception_string}"
                self.exceptions_logger.write(full_string)

    def _resolve_domain_for_listening_socket(self, listening_ip: str, listening_port: int) -> str:
        """Resolve the connection's target domain from engine config when no SNI is provided."""

        if self.engine is None:
            raise RuntimeError("engine is required for _resolve_domain_for_listening_socket")

        destination_domain: str = ''

        # Match the listening IP against the engine's domain targets.
        for domain, ip_port_dict in self.engine.domain_target_dict.items():
            if ip_port_dict['ip'] == listening_ip:
                destination_domain = domain
                break

        # No domain match: resolve the IP for the port via 'on_port_connect'.
        if not destination_domain:
            for port, file_or_ip in self.engine.port_target_dict.items():
                if file_or_ip['ip'] == listening_ip:
                    address_or_file_path: str = self.engine.on_port_connect[str(listening_port)]
                    ip_port_address_from_config = initialize_engines.get_ipv4_from_engine_on_connect_port(
                        address_or_file_path)
                    if not ip_port_address_from_config:
                        raise ValueError(
                            f"Invalid IP address or file path in 'on_port_connect' for port "
                            f"{listening_port}: {address_or_file_path}"
                        )

                    destination_domain = ip_port_address_from_config[0]
                    break

        self.logger.info(f"Requested domain setting: {destination_domain}")
        return destination_domain

    def _serve_connection(
            self,
            client_socket,
            client_address: tuple,
            engine_name: str,
            destination_domain: str,
            dest_port: int,
            callable_function: Callable[..., Any],
            callable_args: tuple
    ):
        """
        Handle an accepted connection in its own thread.
        Performs process name detection, TLS detection, SSL wrapping,
        and invokes the callable_function.

        :param client_socket: socket, client socket that was accepted.
        :param client_address: tuple, (ip_address, port) of the client.
        :param engine_name: string, engine name.
        :param destination_domain: string, domain from engine config.
        :param dest_port: int, destination port.
        :param callable_function: callable, function to execute for this connection.
        :param callable_args: tuple, additional arguments for callable_function.
        """

        # Python auto-names this thread "Thread-N (_serve_connection)". Strip the suffix now so
        # the connection-setup logs read "Thread-N", matching the name the worker later composes.
        threads.strip_current_thread_name_suffix()

        source_ip: str = client_address[0]
        source_port: int = client_address[1]
        process_name: str = ''

        # Engine source_ip: a client the engine isn't bound to gets no engine (general module).
        # DNS already routes such clients elsewhere; this covers stale OS DNS caches and hardcoded IPs.
        connection_engines: list = [self.engine]
        if self.engine is not None and self.engine.source_ip and self.engine.source_ip != source_ip:
            connection_engines = []
            engine_name = ''
            self.logger.info(
                f"Client [{source_ip}] doesn't match engine [{self.engine.engine_name}] "
                f"source_ip [{self.engine.source_ip}]: engine not assigned, general module handles the connection.")
        connection_engine = connection_engines[0] if connection_engines else None

        # The origin is dialed at accept-time below. Track it and whether it was handed to the
        # worker, so a failed client handshake / early return / pre-dispatch exception doesn't
        # abandon the upstream TLS connection (the worker's finish_thread owns it once handed off).
        origin_socket_client = None
        handed_off: bool = False

        try:
            # This is the earliest stage to ask for process name.
            # SSH Remote / LOCALHOST script execution to identify process section.
            # If 'get_process_name' was set to True, then this will be executed.
            if self.get_process_name:
                # Ask the central SSH broker to resolve this connection's source port to the
                # owning process command line. The broker owns one SSH connection per target
                # computer; lookup() returns a command-line string (or an error string) and
                # never raises, so a slow/failed lookup can't stall this connection.
                process_name = self.ssh_lookup_client.lookup(
                    source_ip, source_port, self.ssh_user, self.ssh_pass)

            # ---- Consume the ClientHello up front (sans-io pattern) ----
            # https://github.com/brettcannon/sans-io
            # https://sans-io.readthedocs.io/
            # Sans-io best practice
            # ---------------------
            # Read the first bytes into a buffer, inspect them, then replay
            # them into the real handshake — TLS path via MemoryBIO,
            # non-TLS path via BufferedSocket. No bytes are lost.
            is_tls: bool = False
            client_alpn_offers: list[str] | None = None
            prefetched_bytes: bytes = b''
            tls_properties = None

            try:
                is_tls, client_alpn_offers, prefetched_bytes, tls_properties = (
                    ssl_base.consume_client_hello(client_socket, timeout=10))
            except (TimeoutError, ConnectionError) as exc:
                # ClientHello sniff aborted — timed out or peer hung up. Drop the socket either way.
                error: str
                if isinstance(exc, TimeoutError):
                    error = "TimeoutError: ClientHello consumption timed out. Dropping accepted socket."
                else:
                    error = f"ConnectionError: peer closed before ClientHello completed: {exc}"

                self.logger.error(error)
                self.statistics_writer.write_accept_error(
                    engine=engine_name,
                    source_ip=source_ip,
                    error_message=error,
                    dest_port=str(dest_port),
                    host=destination_domain,
                    process_name=process_name)
                client_socket.close()
                return

            if tls_properties is not None:
                tls_type, tls_version = tls_properties
            else:
                tls_type, tls_version = None, None

            # ---- Accept-time origin connection (mirror source) ----
            # Connect the origin BEFORE completing the client handshake so we can mirror its
            # negotiated ALPN (and clone its cert). Offline keeps no origin leg.
            origin_socket_client = None
            origin_socket = None
            origin_connect_error = None
            server_alpn_protocols = client_alpn_offers   # default (offline / connect failure) = today's behavior
            if not self.is_offline:
                sni_host = ssl_base.parse_sni_from_client_hello_record(prefetched_bytes) if is_tls else None
                origin_target = socket_client.select_origin_target(sni_host, destination_domain)
                origin_socket_client = socket_client.create_origin_socket_client(
                    server_name=origin_target, service_port=dest_port, client_ip=source_ip,
                    is_tls=is_tls, mtls_subdomains=(connection_engine.mtls if connection_engine else None),
                    logger=self.logger,
                    enable_sslkeylogfile_env_to_client_ssl_context=self.enable_sslkeylogfile_env_to_client_ssl_context,
                    sslkeylog_file_path=self.sslkeylog_file_path,
                    forwarding_dns_servers_list=self.forwarding_dns_service_ipv4_list___only_for_localhost,
                    client_alpn_offers=client_alpn_offers)
                origin_socket, origin_connect_error = origin_socket_client.service_connection()
                if origin_connect_error:
                    self.logger.error(f"Origin connect failed: {origin_connect_error}")
                    if self.fail_fast_on_origin_connect_error:
                        self.statistics_writer.write_accept_error(
                            engine=engine_name, source_ip=source_ip,
                            error_message=f"Origin unreachable (fail-fast): {origin_connect_error}",
                            dest_port=str(dest_port), host=destination_domain, process_name=process_name)
                        client_socket.close()
                        return
                    # preserve-today: complete the client handshake with a generated cert + raw client offers;
                    # null the client so cert-cloning is skipped (no dead-socket clone) and the worker records the error.
                    origin_socket_client = None
                elif is_tls:
                    server_alpn_protocols = socket_client.mirror_alpn_list(origin_socket.selected_alpn_protocol())

            # ---- TLS path: hand the consumed bytes to the BIO pump ----
            ssl_client_socket = None
            if is_tls:
                self.logger.info(f"Captured ALPN offers from ClientHello: {client_alpn_offers}")

                sni_handler = sni.SNISetup(
                    default_server_certificate_usage=self.default_server_certificate_usage,
                    default_server_certificate_name=self.default_server_certificate_name,
                    default_certificate_domain_list=self.default_certificate_domain_list,
                    default_server_certificate_directory=self.default_server_certificate_directory,
                    sni_custom_callback_function=self.sni_custom_callback_function,
                    sni_use_default_callback_function=self.sni_use_default_callback_function,
                    sni_use_default_callback_function_extended=self.sni_use_default_callback_function_extended,
                    sni_add_new_domains_to_default_server_certificate=(
                        self.sni_add_new_domains_to_default_server_certificate),
                    sni_server_certificates_cache_directory=self.sni_server_certificates_cache_directory,
                    sni_create_server_certificate_for_each_domain=(
                        self.sni_create_server_certificate_for_each_domain),
                    reuse_server_socket_certificate=(
                        self.reuse_server_socket_certificate),
                    reuse_server_socket_certificate_download_directory=(
                        self.reuse_server_socket_certificate_download_directory),
                    skip_extension_id_list=self.skip_extension_id_list,
                    ca_certificate_name=self.ca_certificate_name,
                    ca_certificate_filepath=self.ca_certificate_filepath,
                    custom_server_certificate_usage=self.custom_server_certificate_usage,
                    custom_server_certificate_path=self.custom_server_certificate_path,
                    custom_private_key_path=self.custom_private_key_path,
                    domain_from_dns_server=destination_domain,
                    forwarding_dns_service_ipv4_list___only_for_localhost=(
                        self.forwarding_dns_service_ipv4_list___only_for_localhost),
                    tls=is_tls,
                    exceptions_logger=self.exceptions_logger,
                    enable_sslkeylogfile_env_to_client_ssl_context=self.enable_sslkeylogfile_env_to_client_ssl_context,
                    sslkeylog_file_path=self.sslkeylog_file_path,
                    mtls_subdomains=connection_engine.mtls if connection_engine else None,
                    server_alpn_protocols=server_alpn_protocols,
                    origin_socket_client=origin_socket_client,
                )

                # ``prefetched=prefetched_bytes`` is the whole point of the
                # consume+MemoryBIO refactor: the consumed ClientHello bytes
                # are re-injected into a ``MemoryBIO`` inside
                # ``wrap_bio_server_with_error_message`` so OpenSSL sees the
                # same record that ``consume_client_hello`` parsed. Without
                # this, OpenSSL would read an empty socket and deadlock on
                # the first ``SSLWantReadError``.
                ssl_client_socket, accept_error_message = \
                    sni_handler.wrap_socket_with_ssl_context_server_sni_extended(
                        client_socket,
                        prefetched=prefetched_bytes,
                        print_kwargs={'logger': self.logger}
                    )

                if ssl_client_socket:
                    # Handshake is done at this point, so version/cipher are available
                    self.logger.info(
                        f"TLS version={ssl_client_socket.version()} cipher={ssl_client_socket.cipher()} "
                        f"alpn_selected={ssl_client_socket.selected_alpn_protocol()!r}"
                    )

                if accept_error_message:
                    # Write statistics after wrap if there was an error.
                    self.statistics_writer.write_accept_error(
                        engine=engine_name,
                        source_ip=source_ip,
                        error_message=accept_error_message,
                        dest_port=str(dest_port),
                        host=destination_domain,
                        process_name=process_name)

                    return

                # Get the real tls version after connection is wrapped.
                tls_version = ssl_client_socket.version()

                # No engine matched the destination domain, so engine_name is empty — fall back to the SNI.
                if engine_name == '':
                    sni_hostname: str = ssl_client_socket.server_hostname
                    if sni_hostname:
                        engine_name = get_engine_name(sni_hostname, connection_engines)

            # Swap to SSL socket if available.
            if ssl_client_socket:
                # In order to use the same object, it needs to get nullified first, since the old instance
                # will not get overwritten. Though it still will show in the memory as SSLSocket, it will not
                # be handled as such, but as regular raw socket.
                # noinspection PyUnusedLocal
                client_socket = None
                client_socket = ssl_client_socket
            elif not is_tls and prefetched_bytes:
                # ---- Non-TLS path: replay the sniff bytes ----
                # ``consume_client_hello`` already pulled bytes off the
                # kernel socket; downstream protocol parsers (HTTP, plain
                # MQTT, etc.) expect to see those same bytes at the head
                # of the stream. ``BufferedSocket`` replays them
                # transparently: its ``recv`` drains the prefetched
                # buffer first, then falls through to the raw socket.
                # Without this wrap, the first ``recv()`` on the worker
                # thread would skip past the ClientHello-shaped bytes we
                # just consumed and start reading from wherever the
                # kernel buffer now sits.
                client_socket = buffered_socket.BufferedSocket(
                    client_socket, prefetched_bytes)

            # Build args and call the callable_function directly (we're already in a thread).
            thread_args = (
                (client_socket, process_name, is_tls, tls_type, tls_version, destination_domain,
                 self.statistics_writer, connection_engines, client_alpn_offers,
                 origin_socket_client, origin_socket, origin_connect_error) + callable_args)

            # Ownership of the origin socket transfers to the worker here; its finish_thread closes it.
            handed_off = True
            try:
                callable_function(*thread_args)
            except Exception as e:
                self.exceptions_logger.write(
                    e, custom_exception_attribute='engine_name',
                    custom_exception_attribute_placement='before')

        except (
            ConnectionResetError, EOFError, TimeoutError,
            paramiko.ssh_exception.SSHException, paramiko.ssh_exception.NoValidConnectionsError,
            ssh_remote.SSHRemoteWrapperNoPythonFound
        ) as e:
            exception_string: str = tracebacks.get_as_string()
            full_string: str = f"{str(e)} | {exception_string}"
            self.statistics_writer.write_accept_error(
                engine=engine_name,
                source_ip=source_ip,
                error_message=full_string,
                dest_port=str(dest_port),
                host=destination_domain,
                process_name=process_name)
        except Exception as e:
            _ = e
            exception_string: str = tracebacks.get_as_string()
            full_string: str = f"Engine: [{engine_name}] | {exception_string}"
            self.exceptions_logger.write(full_string)
        finally:
            # If the origin was connected at accept-time but never handed to the worker
            # (client-handshake failure, early return, or a pre-dispatch exception), the worker's
            # finish_thread never runs — close the upstream leg here so we don't abandon a live
            # upstream TLS connection. close_socket() is not None-safe, so guard on socket_instance.
            if not handed_off and origin_socket_client is not None \
                    and origin_socket_client.socket_instance is not None:
                try:
                    origin_socket_client.close_socket()
                except OSError:
                    pass


def before_socket_thread_worker(
        callable_function: Callable[..., Any],
        callable_args: tuple,
        exceptions_logger: loggingw.ExceptionCsvLogger = None
):
    """
    Function that will be executed before the thread is started.
    :param callable_function: callable, function that will be executed in the thread.
    :param callable_args: tuple, arguments that will be passed to the function.
    :param exceptions_logger: loggingw.ExceptionCsvLogger, logger object that will be used to log exceptions.
    :return:
    """

    try:
        callable_function(*callable_args)
    except Exception as e:
        exceptions_logger.write(e, custom_exception_attribute='engine_name', custom_exception_attribute_placement='before')


def get_engine_name(domain: str, engine_list: list):
    """
    Function that will get the engine name from the domain name.
    :param domain: string, domain name.
    :param engine_list: list that contains the engine names and domains.
    :return: string, engine name.
    """

    engine_name: str = ''
    for engine in engine_list:
        # Get engine name by domain.
        if domain in engine.domain_target_dict:
            engine_name = engine.engine_name

        # If didn't find by domain, try to find by port.
        if engine_name == '':
            for port, ip_port_to_connect_value in engine.on_port_connect.items():
                ipv4_to_connect, _ = initialize_engines.get_ipv4_from_engine_on_connect_port(ip_port_to_connect_value)
                if ipv4_to_connect == domain:
                    engine_name = engine.engine_name
                    break

    return engine_name