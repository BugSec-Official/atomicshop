DEFAULT_PORT: str = '9200'
DEFAULT_HOST: str = 'localhost'
DEFAULT_URL: str = f"http://{DEFAULT_HOST}:{DEFAULT_PORT}"
