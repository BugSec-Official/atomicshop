from atomicshop.wrappers.dockerw import install_docker


def main():
    install_docker.install_docker_ubuntu()


if __name__ == '__main__':
    main()
