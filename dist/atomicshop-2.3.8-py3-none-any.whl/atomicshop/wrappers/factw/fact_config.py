FACT_ADDRESS: str = 'http://localhost:5000'
FIRMWARE_ENDPOINT: str = '/rest/firmware'
FILE_OBJECT_ENDPOINT: str = '/rest/file_object'
STATUS_ENDPOINT: str = '/rest/status'
