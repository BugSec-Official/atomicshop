"""
If Else one-liner:
    <True statement> if <test> else <False statement>
Only if without else:
    <True statement> if <test> else None
Example:
    True if test_variable == '1' else None
"""