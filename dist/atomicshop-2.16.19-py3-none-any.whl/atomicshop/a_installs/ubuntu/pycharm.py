import sys

from atomicshop.wrappers.pycharmw import ubuntu


if __name__ == '__main__':
    sys.exit(ubuntu.install_main())
