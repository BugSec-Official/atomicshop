sudo apt-get install libpq-dev
pip install psycopg2-binary
pip install psycopg2