def is_divisible(n, k):
    """Return True if n is divisible by k, False otherwise."""

    if n % k == 0:
        return True
    else:
        return False
