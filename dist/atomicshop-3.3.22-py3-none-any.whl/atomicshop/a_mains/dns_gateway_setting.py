import sys

from atomicshop import dns


def main():
    dns.default_dns_gateway_main()


if __name__ == '__main__':
    sys.exit(main())
