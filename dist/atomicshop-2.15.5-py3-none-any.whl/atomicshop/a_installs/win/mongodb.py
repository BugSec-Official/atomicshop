from atomicshop.wrappers.mongodbw import install_mongodb


def main():
    install_mongodb.download_install_latest_main()


if __name__ == "__main__":
    main()
