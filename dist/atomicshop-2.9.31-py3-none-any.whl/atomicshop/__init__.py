"""Atomic Basic functions and classes to make developer life easier"""

__author__ = "Den Kras"
__version__ = '2.9.31'
