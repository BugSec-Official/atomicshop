from datetime import datetime

from ..wrappers.socketw import receiver, sender, socket_client, base
from ..http_parse import HTTPRequestParse, HTTPResponseParse
from ..basics.threads import current_thread_id
from ..print_api import print_api

from .message import ClientMessage
from .initialize_engines import assign_class_by_domain
from . import config_static


# Thread function on client connect.
def thread_worker_main(
        function_client_socket_object,
        process_commandline: str,
        is_tls: bool,
        tls_type: str,
        tls_version: str,
        domain_from_dns,
        network_logger,
        statistics_writer,
        engines_list,
        reference_module
):
    def output_statistics_csv_row():
        status_code = ','.join([str(x.code) for x in client_message.response_list_of_raw_decoded])
        response_size_bytes = ','.join([str(len(x)) for x in client_message.response_list_of_raw_bytes])

        statistics_writer.write_row(
            host=client_message.server_name,
            tls_type=tls_type,
            tls_version=tls_version,
            protocol=client_message.protocol,
            path=client_message.request_raw_decoded.path,
            status_code=status_code,
            command=client_message.request_raw_decoded.command,
            request_time_sent=client_message.request_time_received,
            request_size_bytes=len(client_message.request_raw_bytes),
            response_size_bytes=response_size_bytes,
            recorded_file_path=recorded_file,
            process_cmd=process_commandline,
            error=str())

    try:
        # Defining variables before assignment
        function_recorded: bool = False
        client_message: ClientMessage = ClientMessage()
        request_decoded = None
        service_client = None

        # Getting thread ID of the current thread and putting to the client message class
        client_message.thread_id = current_thread_id()
        # Get client ip and port
        client_message.client_ip, client_message.source_port = function_client_socket_object.getpeername()
        # Get destination port
        client_message.destination_port = function_client_socket_object.getsockname()[1]
        # Putting the process command line.
        client_message.process_name = process_commandline

        # Only protocols that are encrypted with TLS have the server name attribute.
        if is_tls:
            # Get current destination domain
            client_message.server_name = function_client_socket_object.server_hostname
            # client_message.server_name = domain_from_dns
        # If the protocol is not TLS, then we'll use the domain from the DNS.
        else:
            client_message.server_name = domain_from_dns

        network_logger.info(f"Thread Created - Client [{client_message.client_ip}:{client_message.source_port}] | "
                            f"Destination service: [{client_message.server_name}:{client_message.destination_port}]")

        # Loading parser by domain, if there is no parser for current domain - general reference parser is loaded.
        # These should be outside any loop and initialized only once entering the thread.
        parser, responder, recorder = assign_class_by_domain(
            engines_usage=config_static.TCPServer.engines_usage,
            engines_list=engines_list,
            message_domain_name=client_message.server_name,
            reference_module=reference_module,
            logger=network_logger
        )

        # Defining client connection boolean variable to enter the loop
        client_connection_boolean: bool = True

        # Loop while received message is not empty, if so, close socket, since other side already closed.
        while client_connection_boolean:
            # Don't forget that 'ClientMessage' object is being reused at this step.
            # Meaning, that each list / dictionary that is used to update at
            # this loop section needs to be reinitialized.
            # Add any variables that need reinitializing in the 'ClientMessage' class 'reinitialize' function.
            client_message.reinitialize()

            # Initialize statistics_dict for the same reason as 'client_message.reinitialize()'.
            # statistics_dict: dict = dict()
            # statistics_dict['host'] = client_message.server_name
            # statistics_dict['path'] = str()
            # statistics_dict['status_code'] = str()
            # statistics_dict['command'] = str()
            # statistics_dict['request_time_sent'] = str()
            # statistics_dict['request_size_bytes'] = str()
            # # statistics_dict['response_time_sent'] = str()
            # statistics_dict['response_size_bytes'] = str()
            # statistics_dict['file_path'] = str()
            # statistics_dict['process_cmd'] = str()
            # statistics_dict['error'] = str()

            network_logger.info("Initializing Receiver")
            # Getting message from the client over the socket using specific class.
            client_received_raw_data = receiver.Receiver(function_client_socket_object).receive()

            # If the message is empty, then the connection was closed already by the other side,
            # so we can close the socket as well.
            # If the received message from the client is not empty, then continue.
            if client_received_raw_data:
                # Putting the received message to the aggregating message class.
                client_message.request_raw_bytes = client_received_raw_data
                # Getting current time of message received from client.
                client_message.request_time_received = datetime.now()

                # HTTP Parsing section =================================================================================
                # Parsing the raw bytes as HTTP.
                try:
                    request_decoded = HTTPRequestParse(client_message.request_raw_bytes)
                except Exception:
                    message = "There was an exception in HTTP Parsing module!"
                    print_api(
                        message, error_type=True, logger=network_logger, logger_method='critical',
                        traceback_string=True, oneline=True)
                    # Socket connection can be closed since we have a problem in current thread and break the loop
                    client_connection_boolean = False
                    break

                # Getting the status of http parsing
                request_is_http, http_parsing_reason, http_parsing_error = request_decoded.check_if_http()

                # Currently, we don't care if it's HTTP. If there was no error we can continue. Just log the reason.
                if not http_parsing_error:
                    network_logger.info(http_parsing_reason)
                # If there was error - the request is really HTTP, but there's a problem with its structure.
                # So, we'll stop the loop.
                else:
                    client_message.error = http_parsing_reason
                    network_logger.critical(client_message.error)
                    break

                # If the request is HTTP protocol.
                if request_is_http:
                    client_message.protocol = 'HTTP'
                    network_logger.info(f"Method: {request_decoded.command}")
                    network_logger.info(f"Path: {request_decoded.path}")
                    # statistics.dict['path'] = request_decoded.path
                    client_message.request_raw_decoded = request_decoded
                # HTTP Parsing section EOF =============================================================================

                # Catching exceptions in the parser
                try:
                    parser(client_message).parse()
                except Exception:
                    message = "Exception in Parser"
                    print_api(
                        message, error_type=True, logger=parser.logger, logger_method='critical',
                        traceback_string=True, oneline=True)
                    print_api(
                        message, error_type=True, logger=network_logger, logger_method='critical',
                        traceback_string=True, oneline=True)
                    # At this point we can pass the exception and continue the script.
                    pass
                    # Socket connection can be closed since we have a problem in current thread and break the loop
                    client_connection_boolean = False
                    break

                # Converting body parsed to string, since there is no strict rule for the parameter to be string.
                # Still going to put exception on it, since it is not critical for the server.
                # Won't even log the exception.
                try:
                    parser.logger.info(f"{str(client_message.request_body_parsed)[0: 100]}...")
                except Exception:
                    pass

                # If we're in response mode, execute responder.
                if config_static.TCPServer.server_response_mode:
                    # Since we're in response mode, we'll record the request anyway, after the responder did its job.
                    client_message.info = "In Server Response Mode"

                    # Re-initiate the 'client_message.response_list_of_raw_bytes' list, since we'll be appending
                    # new entries for empty list.
                    client_message.response_list_of_raw_bytes = list()
                    # Creating response for parsed message and printing
                    try:
                        responder.create_response(client_message)
                    except Exception:
                        message = "Exception in Responder"
                        print_api(
                            message, error_type=True, logger=responder.logger, logger_method='critical',
                            traceback_string=True, oneline=True)
                        print_api(
                            message, error_type=True, logger=network_logger, logger_method='critical',
                            traceback_string=True, oneline=True)
                        pass
                        # Socket connection can be closed since we have a problem in current thread and break the loop.
                        client_connection_boolean = False
                        break

                    # Output first 100 characters of all the responses in the list.
                    for response_raw_bytes in client_message.response_list_of_raw_bytes:
                        if response_raw_bytes:
                            responder.logger.info(f"{response_raw_bytes[0: 100]}...")
                        else:
                            responder.logger.info(f"Response empty...")
                # Else, we're not in response mode, then execute client connect and record section.
                else:
                    # If "service_client" object is not defined, we'll define it.
                    # If it's defined, then it means there's still active "ssl_socket" with connection to the service
                    # domain.
                    if not service_client:
                        # If we're on localhost, then use external services list in order to resolve the domain:
                        # config['tcp']['forwarding_dns_service_ipv4_list___only_for_localhost']
                        if client_message.client_ip in base.THIS_DEVICE_IP_LIST:
                            service_client = socket_client.SocketClient(
                                service_name=client_message.server_name, service_port=client_message.destination_port,
                                tls=is_tls,
                                dns_servers_list=
                                config_static.TCPServer.forwarding_dns_service_ipv4_list___only_for_localhost)
                        # If we're not on localhost, then connect to domain directly.
                        else:
                            service_client = socket_client.SocketClient(
                                service_name=client_message.server_name, service_port=client_message.destination_port,
                                tls=is_tls)

                    # Sending current client message and receiving a response.
                    # If there was an error it will be passed to "client_message" object class and if not, "None" will
                    # be passed.
                    # If there was connection error or socket close, then "ssl_socket" of the "service_client"
                    # will be empty.
                    response_raw_bytes, client_message.error, client_message.server_ip, service_ssl_socket =\
                        service_client.send_receive_to_service(client_message.request_raw_bytes)

                    # Since we need a list for raw bytes, we'll add the 'response_raw_bytes' to our list object.
                    # But we need to re-initiate it first.
                    client_message.response_list_of_raw_bytes = list()
                    client_message.response_list_of_raw_bytes.append(response_raw_bytes)

                    client_message.response_list_of_raw_decoded = list()
                    # Make HTTP Response parsing only if there was response at all.
                    if response_raw_bytes:
                        response_raw_decoded = HTTPResponseParse(response_raw_bytes).response_raw_decoded
                        client_message.response_list_of_raw_decoded.append(response_raw_decoded)

                    # So if the socket was closed and there was an error we can break the loop
                    if not service_ssl_socket:
                        break

                # This is the point after the response mode check was finished.
                # Recording the message, doesn't matter what type of mode this is.
                try:
                    recorded_file = recorder(class_client_message=client_message,
                                             record_path=config_static.Recorder.recordings_path).record()
                except Exception:
                    message = "Exception in Recorder"
                    print_api(
                        message, error_type=True, logger=recorder.logger, logger_method='critical',
                        traceback_string=True, oneline=True)
                    print_api(
                        message, error_type=True, logger=network_logger, logger_method='critical',
                        traceback_string=True, oneline=True)
                    pass

                function_recorded = True

                # Save statistics file.
                output_statistics_csv_row()

                try:
                    # If there is a response, then send it.
                    if response_raw_bytes:
                        # Sending response/s to client no matter if in record mode or not.
                        network_logger.info(
                            f"Sending messages to client: {len(client_message.response_list_of_raw_bytes)}")
                        function_data_sent = None

                        # Iterate through the list of byte responses.
                        for response_raw_bytes in client_message.response_list_of_raw_bytes:
                            function_data_sent = sender.Sender(function_client_socket_object, response_raw_bytes).send()

                            # If there was problem with sending data, we'll break current loop.
                            if not function_data_sent:
                                break
                    # If there is no response, close the socket.
                    else:
                        function_data_sent = None
                        network_logger.info(f"Response empty, nothing to send to client.")
                except Exception:
                    message = "Not sending anything to the client, since there is no response available"
                    print_api(
                        message, error_type=True, logger=network_logger, logger_method='critical',
                        traceback_string=True, oneline=True)
                    # Pass the exception
                    pass
                    # Break the while loop
                    break

                # If there was problem with sending data, we'll break the while loop
                if not function_data_sent:
                    break
            else:
                # Ending the while loop, basically we can use 'break'
                client_connection_boolean = False
                # We don't need to record empty message so setting the recorder state to recorded
                function_recorded = True

        # === At this point while loop of 'client_connection_boolean' was broken =======================================
        # If recorder wasn't executed before, then execute it now
        if not function_recorded:
            try:
                recorded_file = recorder(
                    class_client_message=client_message, record_path=config_static.Recorder.recordings_path).record()
            except Exception:
                message = "Exception in Recorder"
                print_api(
                    message, error_type=True, logger=recorder.logger, logger_method='critical',
                    traceback_string=True, oneline=True)
                print_api(
                    message, error_type=True, logger=network_logger, logger_method='critical',
                    traceback_string=True, oneline=True)
                pass

            # Save statistics file.
            output_statistics_csv_row()

        # At this stage there could be several times that the same socket was used to the service server - we need to
        # close this socket as well if it still opened.
        if service_client:
            if service_client.socket_instance:
                service_client.close_socket()

        # If client socket is still opened - close
        if function_client_socket_object:
            function_client_socket_object.close()
            network_logger.info(f"Closed client socket [{client_message.client_ip}:{client_message.source_port}]...")

        network_logger.info("Thread Finished. Will continue listening on the Main thread")
    except Exception:
        message = "Undocumented exception in thread worker"
        print_api(
            message, error_type=True, logger=network_logger, logger_method='critical',
            traceback_string=True, oneline=True)
