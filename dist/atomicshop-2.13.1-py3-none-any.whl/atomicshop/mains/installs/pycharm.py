from atomicshop.wrappers import pycharmw


def main():
    pycharmw.download_install_main()


if __name__ == "__main__":
    main()
