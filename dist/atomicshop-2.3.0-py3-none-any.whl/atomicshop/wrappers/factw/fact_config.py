FACT_ADDRESS: str = 'http://localhost:5000'
FIRMWARE_ENDPOINT: str = '/rest/firmware'
