import os
import time
import shutil
import zipfile

from .print_api import print_api
from . import filesystem


def is_zip_zipfile(file_path: str) -> bool:
    """
    Function checks if the file is a zip file.
    :param file_path: string, full path to the file.
    :return: boolean.
    """

    try:
        with zipfile.ZipFile(file_path) as zip_object:
            zip_object.testzip()
            return True
    except zipfile.BadZipFile:
        return False


def is_zip_magic_number(file_path: str) -> bool:
    """
    Function checks if the file is a zip file using magic number.
    :param file_path: string, full path to the file.
    :return: boolean.

    50 4B 03 04: This is the most common signature, found at the beginning of a ZIP file.
        It signifies the start of a file within the ZIP archive and is present in almost all ZIP files.
        Each file within the ZIP archive starts with this signature.
    50 4B 05 06: This is the end of central directory record signature.
        It's found at the end of a ZIP file and is essential for identifying the structure of the ZIP archive,
        especially in cases where the file is split or is a multi-part archive.
    50 4B 07 08: This signature is used for spanned ZIP archives (also known as split or multi-volume ZIP archives).
        It's found in the end of central directory locator for ZIP files that are split across multiple volumes.
    """

    with open(file_path, 'rb') as file:
        # Read the first 4 bytes of the file
        signature = file.read(4)

    # Check if the signature matches any of the ZIP signatures
    return signature in [b'PK\x03\x04', b'PK\x05\x06', b'PK\x07\x08']


def extract_archive_with_shutil(file_path: str, target_directory: str, **kwargs) -> str:
    """
    Function extracts the archive to target directory.
    Returns full path to extracted directory.
    This function doesn't preserve the original date and time of files from the archive, instead the time of extraction
    will be applied.

    :param file_path: Full file path to archived file to extract.
    :param target_directory: The directory on the filesystem to extract the file to.
    :return: str.
    """

    print_api(f'Extracting {file_path}', **kwargs)

    extracted_directory: str = str()

    try:
        shutil.unpack_archive(file_path, target_directory)
        file_name = file_path.rsplit(os.sep, maxsplit=1)[1]
        file_name_no_extension = file_name.rsplit('.', maxsplit=1)[0]
        extracted_directory: str = target_directory + os.sep + file_name_no_extension
    except Exception as exception_object:
        print_api(f'Error extracting: {file_path}', error_type=True, **kwargs)
        print_api(exception_object, error_type=True, **kwargs)
        pass

    print_api(f'Extracted to: {extracted_directory}', **kwargs)
    return extracted_directory


def extract_archive_with_zipfile(
        archive_path: str,
        extract_directory: str = None,
        files_without_directories: bool = False,
        remove_first_directory: bool = False,
        print_kwargs: dict = None
) -> str:
    """
    Function will extract the archive using standard library 'zipfile'.
    This method preserves original date and time of the files inside the archive.

    :param archive_path: string, full path to archived file.
    :param extract_directory: string, full path to directory that the files will be extracted to.
        If not specified, the files will be extracted to the same directory as the archived file, using the file name
        without extension as the directory name.
    :param files_without_directories: boolean, default 'False'.
        'True': All the files in the archive will be extracted without subdirectories hierarchy.
            Meaning, that if there are duplicate file names, the latest file with the same file name will overwrite
            all the rest of the files with the same name.
        'False': Subdirectory hierarchy will be preserved as it is currently in the archived file.
    :param remove_first_directory: boolean, default is 'False'.
        'True': all the files will be extracted without first directory in the hierarchy.
            Example: package_some_name_1.1.1_build/subdir1/file.exe
            Will be extracted as: subdir/file.exe
    :param print_kwargs: dict, kwargs for print_api.

    :return: string, full path to directory that the files were extracted to.
    """

    if print_kwargs is None:
        print_kwargs = dict()

    # If 'extract_directory' is not specified, extract to the same directory as the archived file.
    if extract_directory is None:
        extract_directory = (
                filesystem.get_file_directory(archive_path) + os.sep +
                filesystem.get_file_name_without_extension(archive_path))

    print_api(f'Extracting to directory: {extract_directory}', **print_kwargs)

    # initiating the archived file path as 'zipfile.ZipFile' object.
    with zipfile.ZipFile(archive_path) as zip_object:
        # '.infolist()' method of the object contains all the directories and files that are in the archive including
        # information about each one, like date and time of archiving.
        for zip_info in zip_object.infolist():
            # '.filename' attribute of the 'infolist()' method is relative path to each directory and file.
            # If 'filename' ends with '/' it is a directory (it doesn't matter if it is windows or *nix)
            # If so, skip current iteration.
            if zip_info.filename[-1] == '/':
                continue

            if files_without_directories:
                # Put into 'filename' the string that contains only the filename without subdirectories.
                zip_info.filename = os.path.basename(zip_info.filename)
            elif remove_first_directory:
                # Cut the first directory from the filename.
                zip_info.filename = zip_info.filename.split('/', maxsplit=1)[1]

            print_api(f'Extracting: {zip_info.filename}', **print_kwargs)

            # Extract current file from the archive using 'zip_info' of the current file with 'filename' that we
            # updated under specified parameters to specified directory.
            zip_object.extract(zip_info, extract_directory)

            # === Change the date and time of extracted file from current time to the time specified in 'zip_info'.
            # Get full path to extracted file.
            extracted_file_path: str = extract_directory + os.sep + zip_info.filename
            # Create needed datetime object with original archived datetime from 'zip_info.date_time'.
            date_time = time.mktime(zip_info.date_time + (0, 0, -1))
            # Using 'os' library, changed the datetime of the file to the object created in previous step.
            os.utime(extracted_file_path, (date_time, date_time))
    print_api('Extraction done.', color="green", **print_kwargs)

    return extract_directory
